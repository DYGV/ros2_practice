import rclpy
from rclpy.node import Node

from ex2_simple_msgs.msg import Person


class Listener(Node):
    def __init__(self):
        super().__init__("listener")
        self.create_subscription(Person, "ex2_simple", self.sub_callback, 10)

    def sub_callback(self, msg):
        self.get_logger().info("{0}: {1}".format(msg.name, msg.gender))


def main(args=None):
    rclpy.init(args=args)
    listener = Listener()
    rclpy.spin(listener)
    listener.destory_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
