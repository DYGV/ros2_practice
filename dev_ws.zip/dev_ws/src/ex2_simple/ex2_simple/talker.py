import random

import rclpy
from rclpy.node import Node

from ex2_simple_msgs.msg import Person


class Talker(Node):
    def __init__(self):
        super().__init__("talker")
        # 第三引数はQoS history(?)
        self.publisher = self.create_publisher(Person, "ex2_simple", 10)
        timer_period = 1.0
        self.timer = self.create_timer(timer_period, self.pub_callback)

    def pub_callback(self):
        msg = Person()
        msg.name = "eisuke"
        msg.gender = "male"
        self.publisher.publish(msg)
        self.get_logger().info("Publishing: {}".format(msg))


def main(args=None):
    rclpy.init(args=args)

    talker = Talker()
    rclpy.spin(talker)
    talker.destory_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
