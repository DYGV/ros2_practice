import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.node import Node
from sensor_msgs.msg import Image

from ex2_msgs.srv import Face


class Talker(Node):
    def __init__(self):
        super().__init__("talker")
        self.declare_parameter("freq", 10)
        self.declare_parameter("video_device", -1)

        freq = self.get_parameter("freq").value
        video_device = self.get_parameter("video_device").value

        self.cam = cv2.VideoCapture(video_device)
        self.bridge = CvBridge()
        cb_group = ReentrantCallbackGroup()
        self.cli = self.create_client(Face, "ex2", callback_group=cb_group)
        self.img_pub = self.create_publisher(Image, "image_display", 10)
        self.req = Face.Request()
        timer_period = 1.0 / freq
        self.timer = self.create_timer(
            timer_period, self.pub_callback, callback_group=cb_group
        )

    def pub_callback(self):
        ret, self.frame = self.cam.read()
        src_gray = cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)
        self.req.image = self.bridge.cv2_to_imgmsg(src_gray, "mono8")
        future = self.cli.call_async(self.req)
        future.add_done_callback(self.draw)

    def draw(self, future):
        boxes = future.result()
        print(boxes)
        cv2.rectangle(
            self.frame,
            (boxes.x, boxes.y),
            (boxes.x + boxes.w, boxes.y + boxes.h),
            (255, 0, 255),
            2,
        )
        self.img_pub.publish(self.bridge.cv2_to_imgmsg(self.frame, "bgr8"))


def main(args=None):
    rclpy.init(args=args)
    talker = Talker()
    rclpy.spin(talker)
    talker.destroy_node()
    talker.cam.release()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
