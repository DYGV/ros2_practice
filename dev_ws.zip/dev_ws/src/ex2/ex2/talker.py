import cv2
import rclpy
from cv_bridge import CvBridge
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.node import Node
from sensor_msgs.msg import Image

from ex2_msgs.msg import Face


class Talker(Node):
    def __init__(self):
        super().__init__("talker")
        self.declare_parameter("freq", 10)
        self.declare_parameter("video_device", -1)
        self.declare_parameter("cascade_path", "")

        freq = self.get_parameter("freq").value
        video_device = self.get_parameter("video_device").value
        cascade_path = self.get_parameter("cascade_path").value

        self.cam = cv2.VideoCapture(video_device)
        self.bridge = CvBridge()
        self.face_cascade = cv2.CascadeClassifier(cascade_path)

        self.msg_pub = self.create_publisher(Face, "ex2", 10)
        self.img_pub = self.create_publisher(Image, "image_display", 10)
        timer_period = 1.0 / freq
        self.create_timer(timer_period, self.pub_callback)

    def pub_callback(self):
        face_msg = Face()
        ret, frame = self.cam.read()
        src_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        boxes = self.face_cascade.detectMultiScale(src_gray)
        if len(boxes) > 0:
            boxes = boxes[0]
            cv2.rectangle(
                frame,
                (boxes[0], boxes[1]),
                (boxes[0] + boxes[2], boxes[1] + boxes[3]),
                (255, 0, 255),
                2,
            )
            face_msg.x = int(boxes[0])
            face_msg.y = int(boxes[1])
            face_msg.w = int(boxes[2])
            face_msg.h = int(boxes[3])

        face_msg.image = self.bridge.cv2_to_imgmsg(frame, "bgr8")

        self.img_pub.publish(face_msg.image)
        self.msg_pub.publish(face_msg)


def main(args=None):
    rclpy.init(args=args)
    talker = Talker()
    rclpy.spin(talker)
    talker.destroy_node()
    talker.cam.release()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
