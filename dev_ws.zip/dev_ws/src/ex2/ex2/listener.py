import rclpy
from cv_bridge import CvBridge
from rclpy.node import Node
from ex2_msgs.msg import Face


class Listener(Node):
    def __init__(self):
        super().__init__("listener")
        self.create_subscription(Face, "ex2", self.callback, 10)
        self.bridge = CvBridge()

    def callback(self, msg):
        image = self.bridge.imgmsg_to_cv2(msg.image, "bgr8")
        print("detect: x={}, y={}, w={}, h={}".format(msg.x, msg.y, msg.w, msg.h))


def main(args=None):
    rclpy.init(args=args)
    listener = Listener()
    rclpy.spin(listener)
    listener.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
