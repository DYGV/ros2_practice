from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription(
        [
            Node(
                package="ex2",
                node_executable="talker",
                output="screen",
                parameters=[
                    {
                        "video_device": -1,
                        "freq": 30,
                        "cascade_path": "/home/eisuke/dev_ws/src/ex2/haarcascade_frontalface_default.xml",
                    }
                ],
            ),
            Node(
                package="ex2",
                node_executable="listener",
                output="screen",
            ),
        ]
    )
